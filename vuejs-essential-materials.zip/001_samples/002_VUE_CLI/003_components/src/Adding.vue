<template>
    <div>
        <!-- Указание - куда необходимо добавить HTML код -->
        <!-- Именованные слоты -->
        <slot name='greets'></slot>
        <slot name='text'></slot>
        <hr>
        <slot name='text'></slot>
    </div>
</template>
<script>
    export default {        
        data() {
            return {}
        }
    }
</script>
<style scoped>
    
</style>

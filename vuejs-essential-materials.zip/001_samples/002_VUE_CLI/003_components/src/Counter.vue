<template>
  <div class="animal">
    <h2>Counter component</h2>
    <button @click="add">Add animal +1</button>
    <button @click="sub">Sub animal -1</button>
  </div>
</template>
<script>
import {eventEmitter} from './main.js';
export default {
  props: ["c"],
  data() {
    return {
        
    };
  },
  methods: {
    add() {
      this.c++;
      this.$emit("adding", this.c);

      // Использование шины событий
      //eventEmitter.$emit('adding');// вызов метода на глобальном уровне
    },
    sub() {
      if (this.c === 0) {
        return;
      } else {
        this.c--;
        this.$emit("substr", this.c);
        // eventEmitter.$emit('substr');
      }
    }
  }  
};
</script>
<style>
</style>
<template>
  <div id="app">
    <h1>{{msg}}</h1>
    <h2>Parent: {{animalName}}</h2>
    <!-- <app-adding>
      <p slot=greets>

    {{sayHello()}}, visitior
      </p>
    <p slot='text'>Hello from adding page</p></app-adding> -->
    <hr>
    <app-animal 
    :name="animalName" 
    :c="counter" 
    @changeAnimalName="changeFromChild($event)"></app-animal>
    <hr>
    <app-counter 
    :c="counter" 
    @adding="counter=$event" 
    @substr="counter=$event"></app-counter>
  </div>
</template>

<script>
import Animal from "./Animal.vue";
import Counter from "./Counter.vue";
import Adding from "./Adding.vue";
export default {
  name: "app",
  data() {
    return {
      msg: "Welcome to Your Vue.js App",
      animalName: "Elephant",
      counter: 0
    };
  },
  components: {
    "app-animal": Animal,
    "app-counter": Counter,
    "app-adding": Adding
  },
  methods: {
    // Метод изменяет данные в родительском компоненте
    changeFromChild(ev) {
      // ЧТо передал объект события
      console.log(ev);
      this.animalName = ev;
    },
    sayHello() {
      return new Date().getHours() < 12
        ? "Good morning"
        : new Date().getHours() < 18
        ? "Good afternoon"
        : "Good evening";
    }
  }
};
</script>

<style>
h2 {
  font-style: italic;
  text-decoration: underline;
}
</style>

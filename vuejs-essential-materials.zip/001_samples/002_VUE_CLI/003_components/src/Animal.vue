<template>
  <div class="animal">
    <h2>Animal component</h2>
    <h4>
      {{name}} ({{c}})
    </h4>
    <button @click='changeAnimal'>Change name</button>
  </div>
</template>
<script>
// import {eventEmitter} from './main.js'
export default {
  props:['name', 
  'c'
  ],
  data() {
    return {
        // c:0
    };
  },
  methods: {
      changeAnimal() {
          // Определение имени в каждом отдельноv компоненте
          this.name = 'DOG';
        //   $emit - уведомление события для родительского компонента 
          this.$emit('changeAnimalName', this.name)
      }
  },
  // этап жизненного цикла - когда элемент был создан, но еще не передался в DOM
//   created() {
//       eventEmitter.$on('adding', () => {this.c++}
//       )
//       eventEmitter.$on('substr', () => {this.c--}
//       )
//   },
};
</script>
<style scoped>
    div.animal {
        width:50%;
        border:2px solid orange;
    }
    div {
        background: pink;
    }
</style>
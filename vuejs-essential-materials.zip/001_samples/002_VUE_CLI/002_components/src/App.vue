<template>
  <div id="app">
    <h1>{{ msg }}</h1>
    <hr>
    <!-- шаблон компонента -->
    <!-- Передача свойства компоненту -->
    <app-cash 
    :currencyPriceFromParent='currencyPrice'
    ></app-cash>
  </div>
</template>

<script>
// Локальное подключение компонента
import Cash from './Cash.vue'
export default {
  name: 'app',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App',
      currencyPrice: 30.50,
      currencyName: 'Dollar'
    }
  },
  // регистрация компонента
  components: {
    'app-cash': Cash
  }
}
</script>

<style>

</style>

<template>
  <div class="cash">
    <h2>Cash component</h2>
    <p>
      {{currencyNameFromParent}} currency:
      <b>{{currencyPriceFromParent.toFixed(2)}}$</b>
    </p>
  </div>
</template>
<script>
export default {
  // Получение данных из родительского компонента
  // Определение того, что на вход - прийдут параметры
  props:
    // Валидация входящего параметра
    { 
        currencyPriceFromParent: Number, 
        currencyNameFromParent: {
            // Тип входящего параметра
            type: String,
            // Значение по умолчанию
            default: 'EURO'
        } },
  data() {
    return {
      //   currencyName: 'Dollar'
      // currencyPrice: 28.10
    };
  }
};
</script>
<style>
b,
p {
  font-size: 1.1em;
}
.cash {
  width: 400px;
  border: 2px solid black;
}
</style>
// Подключение модуля VUE.js
import Vue from 'vue'
// Подключение App компонента
import App from './App.vue'


//Глобальная регистрация компонента

import Phone from './Phone.vue'
Vue.component('app-phone', Phone)

/////////

new Vue({
  // объединение файлов html и экземпляра VUE.js
  el: '#app',
  // render (запускает приложение) h => hyperscript — “скрипт, который генерирует HTML-структуру”
  // App - основной компонент
  render: h => h(App)
})

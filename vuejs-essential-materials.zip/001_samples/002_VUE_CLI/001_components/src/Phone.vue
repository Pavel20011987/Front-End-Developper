<template>
  <div>
    <h2>Global component</h2>
    <h3>Phone: {{ phone }}</h3>
    <p>
      <b>Phone price: {{price}}</b>
    </p>
  </div>
</template>
<script>
export default {
  data() {
    return {
        phone: 'Samsung J9',
        price: 1300
    }
  }
};
</script>
<style>
</style>
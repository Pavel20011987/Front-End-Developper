<template>
<!-- шаблон всего приложения -->
  <div id="app">
    <img src="./assets/logo.png">
    <h1>{{ msg }}</h1>   
    <hr>
    <app-phone></app-phone>
    <hr>
    <app-car></app-car>
  </div>
</template>
<script>
// Логика данного компонента
// экспорт объекта VUE.js по умолчанию - компонент.

import Car from './Car.vue';
export default {
  name: 'app',
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  },
  // Локальное подключение компонента
  components: {
    'app-car': Car
  }
}
</script>

<style>


</style>

<template>
  <div>
    <h2>Local component</h2>
    <h3>Car: {{ car }}</h3>
    <p>
      <b>Car price: {{price}}</b>
    </p>
  </div>
</template>
<script>
export default {
  data() {
    return {
        car: 'Fiat doblo',
        price: 3000
    }
  }
};
</script>
<style>
</style>
import Vue from 'vue'
import App from './App.vue'
import Currency from './Currency.vue'
// https://www.npmjs.com/package/accounting-js
import accounting from 'accounting'
Vue.component('app-currency', Currency);

Vue.filter('currency', (val,dec, c) => 
accounting.formatMoney(val, c, dec))
new Vue({
  el: '#app',
  render: h => h(App)
})

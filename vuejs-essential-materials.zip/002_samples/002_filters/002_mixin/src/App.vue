<template>
  <div id="app">
    <!-- mixins — это гибкий инструмент повторного использования кода в компонентах Vue. 
    Объект примеси может содержать любые опции компонентов. При использовании 
    компонентом примеси, все опции примеси “подмешиваются” к собственным опциям компонента.-->
    <h1>{{ msg }}</h1>
    <hr>
    <input type="text" v-model="search" v-on:keyup.enter='add'>
    <ul>
      <li v-for='(c, index) in current' :key='index'>{{c}}</li>
    </ul>
    <hr>
    
    <app-currency></app-currency>
  </div>
</template>
<script>
import Currency from './mixin.js'
export default {
  name: "app",
  mixins: [Currency],
  data() {
    return {
      msg: "Mixins",     
    }  
  },
  methods: {    
  }
  
};
</script>

<style>
</style>

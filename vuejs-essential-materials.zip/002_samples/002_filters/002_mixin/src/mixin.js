// В случае набора готовой функциональности - используются миксины
// Позволяют избежать дубликации кода
export default {
    data() {
        return {
            price: 500,
            search: '',
            current: ['Dollar', 'Euro', 'Krone', 'Shekel']
        }
    },
    methods: {
        add() {
            this.current.push(this.search);
            this.search = '';
        }
    }
}
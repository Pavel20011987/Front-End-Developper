<template>
  <div>
    <h3>Mixin sample</h3>
    <input type="text" v-model="search" v-on:keyup.enter='add'>
    <ul>
      <li v-for='(c, index) in current' :key='index'>{{c}}</li>
    </ul>
    <p>{{price | currency(2, '&pound;')}}</p>
  </div>
</template>
<script>
import Currency from './mixin.js'
export default {
    // регистрaция миксина для компонента
    mixins: [Currency]
};
</script>
<style>
</style>
import Vue from 'vue'
import App from './App.vue'
// Регистрация фильтров на глобальном уровне
Vue.filter('upper', value => value.toUpperCase());

Vue.filter('lower', value=>value.toLowerCase());

new Vue({
  el: '#app',
  render: h => h(App)
})

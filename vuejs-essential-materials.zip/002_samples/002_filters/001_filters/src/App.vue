<template>
  <div id="app">
    <h1>{{ msg }}</h1>
    <hr>
    <!-- Фильтры не меняют данные в экземпляре Vue, а только лишь их видоизменяют -->
    <h2>{{message | lower}}</h2>
    <h2>{{title | upper}}</h2>
    <h2>{{str | abbr}}</h2>
    <h2>{{name | prepend('Dr.') | upper}}</h2>
    
  </div>
</template>
<script>
export default {
  name: "app",
  data() {
    return {
      msg: "Filters",
      message: "hello, i`m vue",
      title: "KIEV",
      str: "Hyper text markup language",
      name: 'Strange'
    };
  },
  // локальная регистрация фильтра
  filters: {
    abbr(value) {
      let msg = "";
      let arr = value.split(" ");
      arr = arr.map(letter => letter[0].toUpperCase());
      for (var i of arr) {
        msg += i;
      }
      return msg;
    },
    prepend(value, prefix) {
      return `${prefix} ${value}`;
    }
  }
};
</script>
<style>
</style>

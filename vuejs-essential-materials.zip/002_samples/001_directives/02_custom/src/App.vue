<template>
  <div id="app">
    <h1>{{ msg }}</h1>
    <hr>
    <button @click='show = !show'>Show/hide</button>
    <p v-if='show' v-test>Hidden text</p>
    <hr>
    <button @click='counter++'>+1</button>
    <p v-testUpdate>{{counter}}</p>
    <hr>
    <!-- Пользовательская директива -->
    <p v-customColor>Custom directive</p>
    <!-- Пердача параметров в директиву -->
    <p v-customColor='"green"'>Custom directive with argument</p>
    <hr>
    <!-- Аргументы с использованием директивы -->
     <p v-border.dotted v-customColor:color.font>Background argument</p>
     <p  v-border v-customColor:color='"red"'>Border argument</p>
     <div v-border.dashed>Here is div with border</div>
  </div>
</template>

<script>
// Для жизненного цикла директивы можно указать следующие этапы жизненного цикла:
// - bind: вызывается при первичном связывании директивы с элементом.
// - inserted: вызывается после вставки связанного элемента внутрь элемента родителя.
// - update: вызывается после обновления VNode компонента-контейнера, но, до обновления дочерних элементов. 
// Значение директивы к этому моменту может измениться, а может и нет. 
// - componentUpdated: вызывается после обновления как VNode компонента-контейнера, так и VNode его потомков.
// - unbind: вызывается однократно, при отвязывании директивы от элемента.

// Функция этапа жизненного цикла принимает агрументы:
// - el: Элемент, к которому привязана директива. Можно использовать для прямых манипуляций с DOM.
// - binding: Объект, содержащий свойства имени, выражения, агрументов и т. д.этапа
// - vnode: Виртуальный элемент, созданный компилятором Vue.
// - oldVnode: Предыдущий виртуальный элемент, доступный только для хуков update и componentUpdated
export default {
  name: 'app',
  data () {
    return {
      msg: 'Custom directives',
      show: true,
      counter:0
    }
  },
  // Директив, зарегестрированная локально для одного компонента
  directives: {
    border(el, bindings) {
      let style = Object.keys(bindings.modifiers);
      if (style.length !==0) {
        el.style.border = `2px ${style[0]} black`
      } else {
         el.style.border = `2px solid black`
      }
    }
  }
}
</script>


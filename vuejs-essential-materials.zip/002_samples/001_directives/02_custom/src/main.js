import Vue from 'vue'
import App from './App.vue'

// Импорт пользователькой директивы
import Color from './custom.directives'
Vue.directive('customColor', Color)

Vue.directive('test', {
  //Этапы жизненного цикла
  bind(el) {
    console.log('Binding to element');
    // На данном этапе - еще нет родительского элемента
    console.log(el.parentNode);
  },
  
  inserted(el) {
    console.log('Inserted to element')
    console.log(el.parentNode)
  },
  unbind(el) {
    console.log('Unbind from element')
  }
})
Vue.directive('testUpdate', {
  // Предыдущее значение элемента
  update(el) {
    console.log('Updated:',el.innerText)
  },
   // Текущее значение элемента
  componentUpdated(el) {
    console.log('Component Updated:',el.innerText)
  }
})
new Vue({
  el: '#app',
  render: h => h(App)
})

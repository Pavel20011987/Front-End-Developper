export default {
    bind(el, bindings, VNode) {
        // Проверка входящего параметра        
        
            if (bindings.value) {
                if (bindings.arg) {
                    el.style[bindings.arg] = bindings.value
                } 
                else {
                    el.style.background = bindings.value;
                }
            } else {
                let x = Math.floor(Math.random()*255);
                let y = Math.floor(Math.random()*255);
                let z = Math.floor(Math.random()*255);
                if(bindings.arg) {
                    el.style[bindings.arg]=`rgb(${x}, ${y}, ${z})`
                }
                else {
                    el.style.background =`rgb(${x}, ${y}, ${z})`
                }
            }
        
    }
}
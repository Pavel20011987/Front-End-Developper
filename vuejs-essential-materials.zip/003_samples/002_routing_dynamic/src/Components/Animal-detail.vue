<template>
  <div id="app">
    <h2>Animal-detail</h2>
    <h4>{{ msg }} {{name}}</h4>
    <button 
    class='btn-sm btn btn-success' 
    @click='onBackRoute()'>Return</button>
    <router-link 
    class='btn-sm btn btn-secondary' 
    tag='button'
    :to='"/animal/"+name+"/details"'
    >Full info</router-link>
    <router-link 
    class='btn-sm btn btn-warning' 
    tag='button'
    :to='{name: "login", query: {login:"admin@gmail.com", password: "123456"}}'
    >Login page</router-link>
    <!-- query - позволяет передать пользовательские параметры -->
    <!-- Генератор ссылок для сложных машрутов. Передача праметра в дочерний маршрут-->
    <!-- :to='{name: "details", params: {name}}' -->
    <!-- :to='"/animal/"+name+"/details"' -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'Animal:',
      // переменная маршрута
      name: this.$router.currentRoute.params['name']
    }
  },
  created() {
    // объект маршрутизации vue
    console.log(this.$router)
  },
  watch: {
    //  $route - this.$router.currentRoute - текущий маршрут
    // Динамическое отслеживание параметров маршрута
    $route(toRoute, fromRoute) {
      this.name = toRoute.params['name'];
    }
  },
  methods: {
    onBackRoute() {
      // запись в массив испорий браузера новую ссылку
      this.$router.push('/animals')
    }
  }
}
</script>

<style>
  li {
    cursor: pointer;
  }
</style>
<template>
  <div class='mt-2' id="app">    
    <h5>Lives in: <span>{{animal.country}}</span></h5>
    <h5>Favourite food: <span>{{animal.food}}</span></h5>
    
  </div>
</template>

<script>
import Pats from '../mixin.js';
export default {
  mixins: [Pats],
  data () {
    return {
      name: this.$router.currentRoute.params['name'],
      animal:null,
    }
  },
  created() {
     this.pats= this.pats.filter(animal => animal.name === this.name);
     this.animal = this.pats[0];
      
  }  
}
</script>
<style>
    span {
        background: blue;
        color:#fff;
    }
</style>
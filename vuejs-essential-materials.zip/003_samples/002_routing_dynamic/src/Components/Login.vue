<template>
  <div id="app row">
    <h1>{{ msg }}</h1>
    <form class="form-signin col-6">
      <h3 class="h3 mb-3 font-weight-normal">Please sign in</h3>
      <div class="form-group">
        <label for="inputEmail">Email address</label>
        <input
          type="email"
          id="inputEmail"
          v-model="login"
          class="form-control"
          placeholder="Email address"
          required
        >
      </div>
      <div class="form-group">
        <label for="inputPassword">Password</label>
        <input
          type="password"
          id="inputPassword"
          v-model="password"
          class="form-control"
          placeholder="Password"
          required
        >
      </div>
      <button class="btn btn-primary" type="submit">Sign in</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      msg: "Login page",
      login: "",
      password: ""
    };
  },
  created() {
    if (this.$route.query.login) {
      this.login = this.$route.query.login;
      this.password = this.$route.query.password;
    }
 }
};
</script>

<style>
</style>
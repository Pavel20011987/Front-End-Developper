import VueRouter from 'vue-router';
import Home from './Components/Home';
import Animals from './Components/Animals';
import Login from './Components/Login'
import Animal from './Components/Animal-detail';
import Full_info from './Components/Animal-full-info';
export default new VueRouter({
    // Каждому маршруту можно присваивать парметр имени
    routes: [
        {path: '/', component: Home},
        {path: '/animals', component: Animals},
        {path: '/login', component: Login, name: 'login'},
        // отображение динамиского маршрута
        {path: '/animal/:name', component: Animal, 
        children: [
            {path: 'details', component: Full_info, name:'details'}
        ]}
    ],
    
    mode: 'history'
})

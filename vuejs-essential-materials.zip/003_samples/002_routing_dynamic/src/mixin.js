export default {
    data() {
        return {
            pats: [
                {name: 'Tiger', food: 'meat', country: 'Nepal'},
                {name: 'Monkey', food: 'banana', country: 'Brasil'},
                {name: 'Cat', food: 'milk', country: 'Ukraine'},
                {name: 'Bear', food: 'fish', country: 'Russia'}]
        }
    }    
}
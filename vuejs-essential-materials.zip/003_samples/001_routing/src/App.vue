<template>
  <div id="app">
    <div class='container'>
    <h1>{{ msg }}</h1>
    <!-- router-link - элемент для определение маршрутизации -->
    <!-- to - привязка - к маршруту для перенаправления -->
    <!-- tag - на что заменить элемент, если его нет тогда - будет преобразована в tag-->
    <!-- exact - точное определение маршрута -->
    <router-link 
    class='btn btn-secondary' 
    tag='button' 
    to='/' 
    active-class='active-link'
    exact>Home page</router-link>
    <router-link 
    class='btn btn-secondary' 
    :to='"/animals"'  
    active-class='active-link'
    exact>Animals page</router-link>   
    <hr>
    <!-- тег, ответственный за маршрутизацию и отображении дочерних компонентов  -->
    <router-view></router-view>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'Vue-routing'
    }
  }
}
</script>

<style>
.active-link {
  background: red;
}
</style>

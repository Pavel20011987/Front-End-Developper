import VueRouter from 'vue-router';
import Home from './Components/Home';
import Animals from './Components/Animals';
// новый экземпляр класса
// входящий параметр - объект конфигурации
export default new VueRouter({
    // массив маршрутов в приложении
    routes: [
        {path: '/', component: Home},
        {path: '/animals', component: Animals}
    ],
    // history - история посещения всех ссылок
    // hash - определение # в конце маршрута
    mode: 'history'
})

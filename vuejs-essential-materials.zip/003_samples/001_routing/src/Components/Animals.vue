<template>
  <div id="app">
    <h1>{{ msg }}</h1>
    <div v-for='item in pats' :key='item.name'>
        <p>{{item.name}} loves {{item.food}}</p>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'Animals page',
      pats: [
          {name: 'Tiger', food: 'meat'},
          {name: 'Monkey', food: 'banana'},
          {name: 'Cat', food: 'milk'},
          {name: 'Bear', food: 'fish'}]
    }
  }
}
</script>

<style>

</style>
export default {
    data() {
        return {
            pats: [
                { name: 'Tiger', food: 'meat', country: 'Nepal', imgs: ['../../src/assets/tiger1.jpg', '../../src/assets/tiger2.jpg',] },
                { name: 'Monkey', food: 'banana', country: 'Brasil', imgs: ['../../src/assets/monkey1.jpg', '../../src/assets/monkey2.jpg',] },
                { name: 'Cat', food: 'milk', country: 'Ukraine', imgs: ['../../src/assets/cat1.jpg', '../../src/assets/cat2.jpg',] },
                { name: 'Bear', food: 'fish', country: 'Russia', imgs: ['../../src/assets/bear1.jpg', '../../src/assets/bear2.jpg',] }],
            currentUser: {
                email: '',
                password: ''
            },
            isLogin: false
        }
    }
}
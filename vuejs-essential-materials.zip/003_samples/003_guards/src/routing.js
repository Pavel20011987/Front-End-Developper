import VueRouter from 'vue-router';
import Home from './Components/Home';
// import Animals from './Components/Animals';
// import Login from './Components/Login';
import Animal from './Components/Animal-detail';
import Full_info from './Components/Animal-full-info';
// import Error_page from './Components/NotFound';

// Ленивая загрузка позволяет загрузить определенные компоненты по требованию - подгружать только при переходе на них
const Animals = (resolve) => require.ensure(['./Components/Animals'], () => resolve(
    require('./Components/Animals')
))
const Login = (resolve) => require.ensure(['./Components/Login'], () => resolve(
    require('./Components/Login')
))
const Error_page = (resolve) => require.ensure(['./Components/NotFound'], () => resolve(
    require('./Components/NotFound')
))

export default new VueRouter({
    routes: [
        { path: '/', component: Home },
        {
            path: '/animals',
            component: Animals,

        },
        { path: '/login', component: Login, name: 'login' },
        {
            path: '/animal/:name', component: Animal,


            children: [
                { path: 'details', component: Full_info, name: 'details' }
            ]
        },
        { path: '/error', component: Error_page },
        // redirect - перенаправление в случае если существует ошибка маршрута
        { path: '*', redirect: '/error' }
    ],

    mode: 'history',
    // При переходе между страницами в рамках клиентской маршрутизации, 
    // можно сохранять позицию прокрутки для каждой записи в истории 
    // или же прокручивать страницу наверх. vue-router позволяет полностью настроить поведение 
    // прокрутки при навигации.
    // Функция scrollBehavior получает объекты маршрутов tо, from, savedPosition (передаётся 
    //     сохранённая в истории браузера позиция прокрутки scrollBehavior)
    scrollBehavior(to, from, savedPosition) {
        // при использовании кнопок - вперед, назад - вернуть предыдущее положение
        if (savedPosition) {
            return savedPosition
        }
        // использование прокрутки к якорю -автоматический переход к определенному заголовку
        if (to.hash) {
            return { selector: to.hash }
        }
        else {
            return { x: 0, y: 0 }
        }

        // Использование промиса
        // return new Promise((resolve, reject) => {
        //   setTimeout(() => {
        //     resolve({ x: 0, y: 0 })
        //   }, 1000)
        // })

    }
})

<template>
  <div class='mt-2' id="app">    
    <h5>Lives in: <span>{{animal.country}}</span></h5>
    <h5>Favourite food: <span>{{animal.food}}</span></h5>
    <hr>
    <div v-for='(img, index) in animal.imgs' :key='index'>
      <img :src="img" :alt="animal.name">
    </div>
    <!-- Создание футера с якорем -->
    <div class="row bg-warning m-2" id='footer'>
      <div class='col-4 border text-center'>Contacts</div>
      <div class='col-4 border text-center'>About</div>
      <div class='col-4 border text-center'>Policies</div>
    </div>
  </div>
</template>

<script>
import Pats from '../mixin.js';
export default {
  mixins: [Pats],
  data () {
    return {
      name: this.$router.currentRoute.params['name'],
      animal:null,
    }
  },
  created() {
     this.pats= this.pats.filter(animal => animal.name === this.name);
     this.animal = this.pats[0];
     console.log(this.animal)
      
  }  
}
</script>
<style>
    span {
        background: blue;
        color:#fff;
    }
    img {
      width:70%;
      height:400px;
    }
</style>
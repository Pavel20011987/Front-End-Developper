<template>
  <div id="app">
    <h1>{{ msg }}</h1>
    <router-link 
    v-for='(item, index) in pats' 
    :key='index' 
    tag='li'
    :to='"/animal/"+item.name'>{{item.name}}</router-link>
    </div>
</template>

<script>
import Pats from '../mixin.js'
export default {
  mixins: [Pats],
  data () {
    return {
      msg: 'Animals page',
     
    }
  },
  
}
</script>

<style>
  li {
    cursor: pointer;
  }
</style>
<template>
  <div id="app row">
    <div>
      <h1>{{ msg }}</h1>
      <form class="form-signin col-6">
        <h3 class="h3 mb-3 font-weight-normal">Please sign in</h3>
        <div class="form-group">
          <label for="inputEmail">Email address</label>
          <input
            type="email"
            id="inputEmail"
            v-model="currentUser.email"
            class="form-control"
            placeholder="Email address"
            required
          >
        </div>
        <div class="form-group">
          <label for="inputPassword">Password</label>
          <input
            type="password"
            id="inputPassword"
            v-model="currentUser.password"
            class="form-control"
            placeholder="Password"
            required
          >
        </div>
        <button class="btn btn-primary" type="button" @click="singIn">Sign in</button>
      <div v-if="isError" class="alert alert-danger mt-2">{{errorMessage}}</div>
      </form>
    </div>   
  </div>
</template>

<script>
import Pats from "../mixin.js";

export default {
  mixins: [Pats],
  data() {
    return {
      msg: "Login page",
      errorMessage: "Invalid login or password",
      isError: false
    };
  },
  created() {
    if (this.$route.query.login) {
      this.currentUser.email = this.$route.query.login;
      this.currentUser.password = this.$route.query.password;
    }
  },
  methods: {
    singIn() {
       if (
        this.currentUser.email != "admin@gmail.com" &&
        this.currentUser.password != 123456
      ) {
         this.isError = true;
        setTimeout(() => {
          this.isError = false;
        }, 2000);
      } else {
        this.isLogin = true;
        this.$router.push("/animals");
      }
    }
  },
  beforeRouteLeave (to, from, next) {
    // Перед уходом с маршрута
    if(window.confirm('Вы уверены?')) {
      next(true)
    } else {
      next(false)
    }
  }
};
</script>

<style>
</style>
<template>
  <div id="app">
    <h2>Animal-detail</h2>
    <h4>{{ msg }} {{name}}</h4>
    <button class="btn-sm btn btn-success" @click="onBackRoute()">Return</button>
    <router-link
      class="btn-sm btn btn-secondary"
      tag="button"
      :to='{name: "details", params: {name}, hash: "#footer"}'
    >Full info</router-link>
    <router-link
      class="btn-sm btn btn-warning"
      tag="button"
      :to='{name: "login", query: {login:"admin@gmail.com", password: "123456"}}'
    >Login page</router-link>
    <!-- hash: "#footer" - установка якоря в командной строке -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  data() {
    return {
      msg: "Animal:",
      name: this.$router.currentRoute.params["name"]
    };
  },
  created() {
    console.log(this.$router);
  },
  watch: {
    $route(toRoute, fromRoute) {
      this.name = toRoute.params["name"];
    }
  },
  methods: {
    onBackRoute() {
      this.$router.push("/animals");
    }
  },
  beforeRouteEnter(to, from, next) {
    // Перед переходом на маршрут
    console.log("Before Route enter");
    let email = prompt("Enter your email");
    let password = prompt("Enter your password");
    if (email != "admin@gmail.com" && password != "123456") {
      alert("Wrong user");
      next(false);
    } else {
      // разрешаем переходить по маршруту
      next(true);
    }
  }
};
</script>

<style>
li {
  cursor: pointer;
}
</style>
<template>
    <div>
        <h4>User control input</h4>
        <button 
        class='btn'
        :class="[(value === 1) ? 'btn-success': '']"
        @click='switchRunning(1)'
        >Running</button>
        <button 
        class='btn'
        :class="[(value === 0) ? 'btn-danger': '']"
        @click='switchRunning(0)'
        >Brake</button>
        <button 
        class='btn'
        :class="[(value === 0.1) ? 'btn-secondary': '']"
        @click='switchRunning(0.1)'
        >Neutral</button>
        <button 
        class='btn'
        :class="[(value === -1) ? 'btn-warning': '']"
        @click='switchRunning(-1)'
        >Rear transmission</button>
        
    </div>
</template>
<script>
export default {
    // Входящий параметр
    props: ['value'],
    data() {
        return {
          
        }
    },
    methods: {
        switchRunning(val) {
            // генерация события родительскому компоненту
            this.$emit('input', val)
        }
    },
}
</script>
<style>

</style>

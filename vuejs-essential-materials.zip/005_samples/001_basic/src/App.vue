<template>
  <div id="app" class='container'>   
    <h1>{{ msg }}</h1>
    <hr>
    <h4>v-model directive with lazy directive</h4>
    <input type='text' class='form-control' v-model.lazy="input_search">
    <p>{{input_search}}</p>
    <hr>
    <h4>textarea</h4>
    <textarea  class='form-control' v-model='textarea_search'></textarea>
    <p class='textarea'>{{textarea_search}}</p>
    <hr>
    <h4>checkbox</h4>
    <input type="checkbox" value='iphone' v-model='mobile'> iPhone
    <input type="checkbox" value='samsung' v-model='mobile'> Samsung
    <input type="checkbox" value='meizu' v-model='mobile'> Meizu
    <p>{{mobile}}</p>
    <hr>
    <h4>radio buttons</h4>
    <input type="radio" name='fw' value='angular' v-model='framework'> Angular
    <input type="radio" name='fw' value='react' v-model='framework'> React
    <input type="radio" name='fw' value='vue' v-model='framework'> Vue
    <p>{{framework}}</p>
    <hr>
    <h4>select</h4>
    <select class='form-control' v-model='hero'>
      <option :value='man' v-for='man in heroes' :key='man'>{{man}}</option>
    </select>
    <p>{{hero}}</p>
    <hr>
    <h4>number modificator</h4>
    <!-- Числовой модификатор для текстового поля -->
    <input type="text" class='form-control' v-model.number='year'>
    {{year}}
    <hr>
    <!-- v-model - позволяет передать свойство 'value' в компонент -->
    <app-control v-model='switchForCar'></app-control>
    Включено: 
    <span v-if='switchForCar == 0'>Тормоз</span>
    <span v-if='switchForCar == 1'>Газ</span>
    <span v-if='switchForCar == 0.1'>Нейтралка</span>
    <span v-if='switchForCar == -1'>Задняя передача</span>
  </div>
</template>

<script>
import Control from './UserControl';
export default {
  name: 'app',
  data () {
    return {
      msg: 'Vue forms',
      input_search: '',
      textarea_search: '',
      mobile: [],
      framework: '',
      heroes: ['Aquaman', 'Batman', 'Superman'],
      hero: '',
      year: 1992,
      switchForCar: 0
    }
  },
  components: {
    'app-control': Control
  }  
}
</script>

<style>
.textarea {
  white-space: pre;
}
</style>
import VueRouter from 'vue-router';
import Home from './Components/Home';
import BasicValidation from './Components/BasicValidation';
import Errors from './Components/Errors';
import Password from './Components/Password';
import CustomValidator from './Components/CustomValidator';
export default new VueRouter({
    routes: [
        {path: '/', redirect: 'home'},
        {path: '/basic', component: BasicValidation},
        {path: '/home', component: Home},
        {path: '/error', component: Errors},
        {path: '/password', component: Password},
        {path: '/custom', component: CustomValidator},
        
    ],   
    mode: 'history'
})

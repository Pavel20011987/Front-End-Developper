<template>
  <div id="app" class='container'>   
    <h1>{{ msg }}</h1>
    <router-link 
    class='btn btn-secondary' 
    tag='button' 
    to='/' 
    active-class='active-link'
    exact>Home page</router-link>
    <router-link 
    class='btn btn-secondary' 
    :to='"/basic"'  
    active-class='active-link'
    exact>Basic validation</router-link>   
     <router-link 
    class='btn btn-secondary' 
    :to='"/error"'  
    active-class='active-link'
    exact>Showing errors</router-link> 
    <router-link 
    class='btn btn-secondary' 
    :to='"/password"'  
    active-class='active-link'
    exact>Password</router-link>
    <router-link 
    class='btn btn-secondary' 
    :to='"/custom"'  
    active-class='active-link'
    exact>Custom validator</router-link>    
    <hr>
    <router-view></router-view>    
  </div>
</template>

<script>
export default {
  name: 'app',
  data () {
    return {
      msg: 'Vue forms validation'
    }
  }
}
</script>

<style>
.active-link {
  background: red;
}
</style>
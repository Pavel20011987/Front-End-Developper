<template>
  <div>
    <h3>Basic validation</h3>
    <form>
      <div class="form-group">
        <label for="email">Email</label>
        <input
          type="email"
          class="form-control"
          name="email"
          id="email"
          autocomplete="off"
          @blur="$v.email.$touch()"
          :class="{'is-invalid': $v.email.$error, 'is-valid': !$v.email.$error && $v.email.$dirty}"
          v-model="email"
        >
        <div class="valid-feedback">Email is correct</div>
        <div v-if="!$v.email.required" class="invalid-feedback">Email is required!</div>
        <div v-if="!$v.email.email" class="invalid-feedback">Email pattern is invalid!</div>
      </div>
      <div class="form-group">
        <label for="email">Age</label>
        <input
          autocomplete="off"
          type="number"
          class="form-control"
          name="age"
          id="age"
          @blur="$v.age.$touch()"
          :class="{'is-invalid': $v.age.$error, 'is-valid': !$v.age.$error && $v.age.$dirty}"
          v-model="age"
        >
        <div class="valid-feedback">Age is correct</div>
        <div v-if="!$v.age.required" class="invalid-feedback">Age field is required!</div>
        <div v-if="!$v.age.minValue" class="invalid-feedback">You have to be at least 18 years old!</div>
        <div v-if="!$v.age.maxValue" class="invalid-feedback">No longer to live!</div>
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input
          autocomplete="off"
          type="password"
          class="form-control"
          name="password"
          id="password"
          @blur="$v.password.$touch()"
          :class="{'is-invalid': $v.password.$error, 'is-valid': !$v.password.$error && $v.password.$dirty}"
          v-model="password"
        >
        <div class="valid-feedback">Password is correct</div>
        <div v-if="!$v.password.required" class="invalid-feedback">Pasword is required</div>
        <div v-if="!$v.password.minLength" class="invalid-feedback">At least 6 simbols required.
          <span class="float-right">6 / {{password.length}}</span>
        </div>
      </div>
      <div class="form-group">
        <label for="passwordMatch">Password confirm</label>
        <input
          autocomplete="off"
          type="password"
          class="form-control"
          name="passwordMatch"
          id="passwordMatch"
          @blur="$v.passwordMatch.$touch()"
          :class="{'is-invalid': $v.passwordMatch.$error, 'is-valid': !$v.passwordMatch.$error && $v.passwordMatch.$dirty}"
          v-model="passwordMatch"
        >
        <div class="valid-feedback">Checked passwords</div>
        <div v-if="!$v.passwordMatch.sameAs" class="invalid-feedback">Password should match!</div>
      </div>
    </form>
  </div>
</template>
<script>
import {
  required,
  minLength,
  email,
  minValue,
  maxValue,
  sameAs
} from "vuelidate/lib/validators";
export default {
  data() {
    return {
      email: "",
      age: 0,
      password: "",
      passwordMatch: ""
    };
  },
  validations: {
    email: {
      required,
      email
    },
    age: {
      minValue: minValue(18),
      maxValue: maxValue(100),
      required
    },
    password: {
      minLength: minLength(6),
      required
    },
    passwordMatch: {
      //валидатор идентичности
      sameAs: sameAs('password')
    }
  }
};
</script>
<style scoped>
</style>
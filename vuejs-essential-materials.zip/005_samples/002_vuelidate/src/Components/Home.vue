<template>
    <div>
        <h3>Home page</h3>
        <p>https://monterail.github.io/vuelidate/ -страница библиотеки vuelidate</p>
        <p>npm install vuelidate –-save - локальная установка</p>
        <pre>import Vuelidate from 'vuelidate' - использование в проекте
             Vue.use(Vuelidate)</pre>
    </div>
</template>
<script>
export default {
    data() {
        return {
            
        }
    },
}
</script>
<style scoped>

</style>



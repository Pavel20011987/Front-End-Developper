<template>
  <div>
    <h3>Basic validation</h3>
    <form>
      <div class="form-group">
        <label for="email">Email</label>
        <!-- @input="$v" - доступ к коллекции валидаторов -->
        <!-- $touch() - инициализация валидации при определенном событии-->
        <input 
        type="email" 
        class="form-control" 
        name="email" 
        id="email"
        autocomplete="off"
        @blur="$v.email.$touch()"
        v-model='email'>
      </div>
        <pre>
            {{$v}}
        </pre>
      <div class="form-group">
        <label for="email">Age</label>
        <input 
        autocomplete="off"
        type="number" 
        class="form-control" 
        name="age" 
        id="age"
        @blur="$v.age.$touch()"
        v-model='age'>
        </div>
    </form>
  </div>
</template>
<script>
// Импорт встроенных валидаторов
import { required, maxLength, minLength, email } from 'vuelidate/lib/validators';
export default {
  data() {
    return {
        email: '',
        age: 0
    };
  },
  // Определение валидаторов для полей
  validations: {
      email: {
          // ключ совпадает со значением
          required,
          email
      },
      age: {
          minLength: minLength(1),
          maxLength: maxLength(2),
          required
      }
  }
};
</script>
<style scoped>
</style>
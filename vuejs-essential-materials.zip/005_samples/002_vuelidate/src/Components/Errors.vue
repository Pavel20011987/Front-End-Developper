<template>
  <div>
    <h3>Basic validation</h3>
    <form>
      <div class="form-group">
        <label for="email">Email</label>        
        <input 
        type="email" 
        class="form-control" 
        name="email" 
        id="email"
        autocomplete="off"
        @blur="$v.email.$touch()"
        :class="{'is-invalid': $v.email.$error, 'is-valid': !$v.email.$error && $v.email.$dirty}"
        v-model='email'>
        <div class="valid-feedback">
        Email is correct
      </div>
      <div v-if='!$v.email.required' class="invalid-feedback">
        Email is required!
      </div>
      <div v-if='!$v.email.email' class="invalid-feedback">
        Email pattern is invalid!
      </div>
      </div>       
      <div class="form-group">
        <label for="email">Age</label>
        <input 
        autocomplete="off"
        type="number" 
        class="form-control" 
        name="age" 
        id="age"
        @blur="$v.age.$touch()"
        :class="{'is-invalid': $v.age.$error, 'is-valid': !$v.age.$error && $v.age.$dirty}"
        v-model='age'>
        <div class="valid-feedback">
        Age is correct
      </div>
      <div v-if='!$v.age.required' class="invalid-feedback">
        Age field is required!
      </div>
      <div v-if='!$v.age.minValue' class="invalid-feedback">
        You have to be at least 18 years old!
      </div>
       <div v-if='!$v.age.maxValue' class="invalid-feedback">
        No longer to live!
      </div>      
        </div>
    </form>
  </div>
</template>
<script>
import { required, maxLength, minLength, email, minValue, maxValue } from 'vuelidate/lib/validators';
export default {
  data() {
    return {
        email: '',
        age: 0
    };
  },
  validations: {
      email: {
          required,
          email
      },
      age: {
          minValue: minValue(18),
          maxValue: maxValue(100),
          required
      }
  }
};
</script>
<style scoped>
</style>
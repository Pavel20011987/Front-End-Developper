<template>
    <div>
        <h3>Value: {{ counter }}</h3>
        <h5>{{allChanges}} changes was made</h5>
    </div>
</template>
<script>
export default {
    // отсутствие входящего параметра
    data() {
        return {            
        }
    },
    // Определение вычисляемого свойства
    computed: {
        counter() {
            // this.$store - обращение к глобальному объекту store
           return this.$store.state.counter;
        },
        allChanges() {
            return this.$store.getters.historyLength;
        }
    },
}
</script>
<style>

</style>



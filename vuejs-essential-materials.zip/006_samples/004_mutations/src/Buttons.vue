<template>
  <div>
    <button class="btn btn-primary" @click="increment">+</button>
    <button class="btn btn-primary" @click="decrement">-</button>
    <button class="btn btn-primary" @click="asyncIncrement">Increment by 1 sec</button>
    <button class="btn btn-primary" @click="randomIncrement">Random increment</button>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods: {
    increment() {
      this.$store.commit('increment');
    },
    decrement() {
      this.$store.commit('decrement')
    },
    asyncIncrement() {
      this.$store.commit('asyncIncrement')
    },
    randomIncrement() {
      const random = Math.floor(Math.random() * 10);
      this.$store.commit('randomIncrement', random);
    }
  }
};
</script>
<style scoped>
</style>



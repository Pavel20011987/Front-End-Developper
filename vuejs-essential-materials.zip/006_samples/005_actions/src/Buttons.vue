<template>
  <div>
    <button class="btn btn-primary" @click="increment">+</button>
    <button class="btn btn-primary" @click="decrement">-</button>
    <button class="btn btn-primary" @click="asyncIncrement">Increment by 1 sec</button>
    <button class="btn btn-primary" @click="randomIncrement">Random increment</button>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods: {
    increment() {
      // Вызов action вместо mutation напрямую
      this.$store.dispatch("increment");
      // Вызов mutation
      // this.$store.commit('increment');
    },
    decrement() {
      this.$store.dispatch("decrement");
    },
    asyncIncrement() {
      this.$store.dispatch("asyncIncrement");
    },
    randomIncrement() {
      this.$store.dispatch("randomIncrement");
    }
  }
};
</script>
<style scoped>
</style>



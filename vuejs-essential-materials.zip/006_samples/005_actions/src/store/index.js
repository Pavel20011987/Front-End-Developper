import Vue from 'vue';
// импорт библиотеки
import Vuex from 'vuex';
// глобальное подключение библиотеки для всех компонентов
Vue.use(Vuex);
// конструктор конфигурации
export default new Vuex.Store({
    state: {
        counter: 0,
        history: [],
        limit: 5
    },
    // Определение геттеров. Каждый геттер - фнукция.
    getters: {
        allHistory: (state) => state.history,
        limitedHistory: (state) => {
            const end = state.history.length;
            const begin = (end - state.limit < 0) ? 0 : end - state.limit;
            return state.history.slice(begin, end);
        },
        historyLength: (state) => state.history.length
    },
    // Пoзволяют мутировать состояние - подобие setters
    mutations: {
        increment: (state, payload) => {
            if (payload == undefined) {
                state.counter++;
                state.history.push('Add +1')
            } else if (payload.message) {
                state.counter++;
                state.history.push(payload.message)
            } else {
                state.counter += payload;
                state.history.push('Add +' + payload);
            }
        },
        decrement: (state) => {
            state.counter--;
            state.history.push('Substract -1');
        }
    },
    // Любые синхронные, асинхронные операции
    actions: {
        increment: (context) => {
            console.log(context);
            context.commit('increment');
        },
        decrement: ({ commit }) => {
            commit('decrement');
        },
        asyncIncrement: ({ commit }) => {
            setTimeout(() => {
                commit('increment', { message: 'Add async +1' });
            }, 1000)
        },
        randomIncrement: ({ commit }) => {
            const random = Math.floor(Math.random() * 10);
            commit('increment', random);
        }
    }
})
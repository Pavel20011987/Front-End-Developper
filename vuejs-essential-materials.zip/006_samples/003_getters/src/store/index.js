import Vue from 'vue';
// импорт библиотеки
import Vuex from 'vuex';
// глобальное подключение библиотеки для всех компонентов
Vue.use(Vuex);
// конструктор конфигурации
export default new Vuex.Store({
    state: {
        counter: 0,
        history: [],
        limit: 5
    },
    // Определение геттеров. Каждый геттер - фнукция.
    getters: {
        allHistory: (state) => state.history,        
        limitedHistory: (state) => {
            const end = state.history.length;
            const begin = (end - state.limit < 0) ? 0 : end-state.limit;
            return state.history.slice(begin, end);
        },
        historyLength: (state) => state.history.length
    }
})
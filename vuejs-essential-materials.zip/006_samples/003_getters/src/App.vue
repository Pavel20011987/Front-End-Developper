<template>
  <div id="app" class="container">
    <h1>{{ msg }}</h1>
    <hr>
    <counter></counter>
    <buttons></buttons>
    <hr>
    <history></history>
  </div>
</template>

<script>
import Counter from "./Counter";
import Buttons from "./Buttons";
import History from './History';
export default {
  name: "app",
  data() {
    return {
      msg: "Introducing to VUEX",
      count: 0
      // history: []
    }
  },
  components: {
    counter: Counter,
    buttons: Buttons,
    history: History
  },  
  created() {
    console.log(this.$store);
  }
};
</script>

<style>
</style>

<template>
    <div>
        Choose limit
        <select @change='changeLimit' v-model='limitNumber'>
            <option v-for="(number, index) in limits" :key="index" :value="number">{{number}}</option>
        </select>
        <h3>Actions history (max - {{limit}})</h3>
    <ul>
      <li v-for="(action, index) in history" :key="index">{{action}}</li>
    </ul>
    </div>
</template>
<script>
export default {
    data() {
        return {
            limits: [2,3,5,10],
            limitNumber: 5
        }
    },
    computed: {
    history() {    
    // обращение к геттерам в store - без вызова функции
    //   return this.$store.getters.allHistory;
      return this.$store.getters.limitedHistory;
    },
    limit() {
         return this.$store.state.limit;
    }
  },
  methods: {
      changeLimit() {
          this.$store.state.limit = this.limitNumber
      }
  },
}
</script>


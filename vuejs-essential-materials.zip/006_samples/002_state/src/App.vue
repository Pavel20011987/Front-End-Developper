<template>
  <div id="app" class="container">
    <h1>{{ msg }}</h1>
    <hr>
    <counter></counter>
    <buttons></buttons>
    <hr>Actions history:
    <ul>
      <li v-for="(action, index) in history" :key="index">{{action}}</li>
    </ul>
  </div>
</template>

<script>
import Counter from "./Counter";
import Buttons from "./Buttons";
export default {
  name: "app",
  data() {
    return {
      msg: "Introducing to VUEX",
      count: 0
      // history: []
    }
  },
  components: {
    counter: Counter,
    buttons: Buttons
  },
  computed: {
    history() {
      return this.$store.state.history;
    }
  },
  created() {
    console.log(this.$store);
  }
};
</script>

<style>
</style>

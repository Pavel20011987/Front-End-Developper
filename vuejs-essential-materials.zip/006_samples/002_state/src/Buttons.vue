<template>
  <div>
    <button class="btn btn-primary" @click="increment">+</button>
    <button class="btn btn-primary" @click="decrement">-</button>
    <button class="btn btn-primary" @click="asyncIncrement">Increment by 1 sec</button>
    <button class="btn btn-primary" @click="randomIncrement">Random increment</button>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
  methods: {
    increment() {
      this.$store.state.counter++;
      this.$store.state.history.push('Add +1');
    },
    decrement() {
      this.$store.state.counter--;
      this.$store.state.history.push('Substract -1');
    },
    asyncIncrement() {
      setTimeout(() => {
        this.$store.state.counter++;
        this.$store.state.history.push('Add async +1');
      }, 1000);
    },
    randomIncrement() {
      const random = Math.floor(Math.random() * 10);
      this.$store.state.counter += random;
      this.$store.state.history.push('Add +'+ random);
    }
  }
};
</script>
<style scoped>
</style>



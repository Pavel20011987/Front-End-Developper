import Vue from 'vue';
// импорт библиотеки
import Vuex from 'vuex';
// глобальное подключение библиотеки для всех компонентов
Vue.use(Vuex);
// конструктор конфигурации
export default new Vuex.Store({
    state: {
        counter: 10,
        history: []
    }
})
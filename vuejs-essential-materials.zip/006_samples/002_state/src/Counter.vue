<template>
    <div>
        Value: {{ counter }}
    </div>
</template>
<script>
export default {
    // отсутствие входящего параметра
    data() {
        return {
            
        }
    },
    // Определение вычисляемого свойства
    computed: {
        counter() {
            // this.$store - обращение к глобальному объекту store
           return this.$store.state.counter;
        }
    },
}
</script>
<style>

</style>



<template>
  <div id="app" class='container'>    
    <h1>{{ msg }}</h1>
    <hr>
    <counter :counter='count'></counter>
    <button class='btn btn-primary' @click="increment">+</button>
    <button class='btn btn-primary' @click="decrement">-</button>
    <button class='btn btn-primary' @click="asyncIncrement">Increment by 1 sec</button>
    <button class='btn btn-primary' @click="randomIncrement">Random increment</button>
    <hr>
    Actions history:
    <ul>
      <li v-for="(action, index) in history" :key='index'>{{action}}</li>
    </ul>
  </div>
</template>

<script>
import Counter from './Counter';
export default {
  name: 'app',
  data () {
    return {
      msg: 'Introducing to VUEX',
      count: 0,
      history: []
    }
  },
  components: {
    'counter': Counter
  },
  methods: {
    increment() {
      this.count++
    },
    decrement() {
      this.count--
    },
    asyncIncrement() {
      setTimeout(() => {this.count++}, 1000)
    },
    randomIncrement() {
     const random = Math.floor(Math.random()*10);
     this.count +=random;
    }
  },
}
</script>

<style>

</style>

<template>
    <div>
        Value: {{ counter }}
    </div>
</template>
<script>
export default {
    props: ['counter'],
    data() {
        return {
            
        }
    },
}
</script>
<style>

</style>



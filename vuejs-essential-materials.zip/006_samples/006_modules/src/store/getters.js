export default {
   
    
        allHistory: (state) => state.history,
        limitedHistory: (state) => {
            const end = state.history.length;
            const begin = (end - state.limit < 0) ? 0 : end - state.limit;
            return state.history.slice(begin, end);
        },
        historyLength: (state) => state.history.length,
        getLimit: (state) => state.limit,
        getCounter: (state) => state.counter
    
}
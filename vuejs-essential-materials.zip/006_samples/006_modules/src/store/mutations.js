export default {

        increment: (state, payload) => {
            if (payload == undefined) {
                state.counter++;
                state.history.push('Add +1')
            } else if (payload.message) {
                state.counter++;
                state.history.push(payload.message)
            } else {
                state.counter += payload;
                state.history.push('Add +' + payload);
            }
        },
        decrement: (state) => {
            state.counter--;
            state.history.push('Substract -1');
        },
        changeLimit: (state, payload) => {
            state.limit = payload
        }
    
}
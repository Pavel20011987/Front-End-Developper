export default {
   
        counter: 0,
        history: [],
        limit: 5     
    
}
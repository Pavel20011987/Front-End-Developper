export default {        
        increment: (context) => {
            context.commit('increment');
        },
        decrement: ({ commit }) => {
            commit('decrement');
        },
        asyncIncrement: ({ commit }) => {
            setTimeout(() => {
                commit('increment', { message: 'Add async +1' });
            }, 1000)
        },
        randomIncrement: ({ commit }) => {
            const random = Math.floor(Math.random() * 10);
            commit('increment', random);
        },
        switchLimit: ({ commit }, payload) => {
            commit('changeLimit', payload);
        }
    
}
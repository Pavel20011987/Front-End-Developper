<template>
  <div>
    <button class="btn btn-primary" @click="increment">+</button>
    <button class="btn btn-primary" @click="decrement">-</button>
    <button class="btn btn-primary" @click="asyncIncrement">Increment by 1 sec</button>
    <button class="btn btn-primary" @click="randomIncrement">Random increment</button>
  </div>
</template>
<script>
import { mapActions } from 'vuex'
export default {
  data() {
    return {};
  },
  // mapActions - вспомогательная функция - создающая локальные псевдонимы для действий в виде методов компонента
  methods: mapActions([
    'increment',
    'decrement',
    'asyncIncrement',
    'randomIncrement'
  ])
};
</script>
<style scoped>
</style>



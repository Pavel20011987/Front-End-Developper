<template>
    <div>
        Choose limit
        <select @change='changeLimit' v-model='limitNumber'>
            <option v-for="(number, index) in limits" :key="index" :value="number">{{number}}</option>
        </select>
        <h3>Actions history (max - {{getLimit}})</h3>
    <ul>
      <li v-for="(action, index) in limitedHistory" :key="index">{{action}}</li>
    </ul>
    </div>
</template>
<script>
import { mapGetters } from 'vuex';
export default {
    data() {
        return {
            limits: [2,3,5,10],
            limitNumber: 5
        }
    },
    computed: mapGetters([
        'limitedHistory',
        'getLimit'
    ]),
    methods: {
      changeLimit() {
          this.$store.dispatch('switchLimit', this.limitNumber)
      }
  },
}
</script>


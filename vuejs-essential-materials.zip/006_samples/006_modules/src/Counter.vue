<template>
    <div>
        <h3>Value: {{ getCounter }}</h3>
        <h5>{{historyLength}} changes was made</h5>
    </div>
</template>
<script>
import { mapGetters } from 'vuex'
export default {
    // отсутствие входящего параметра
    data() {
        return {            
        }
    },
    // Определение вычисляемого свойства
    computed: mapGetters([
        'getCounter',
        'historyLength'
    ])
    
}
</script>
<style>

</style>



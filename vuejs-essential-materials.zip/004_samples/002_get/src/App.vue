<template>
  <div id="app">
    <h1>{{ msg }}</h1>
    <hr>
    <form class="col-4">
      <legend>Cars adding</legend>
      <div class="form-group">
        <label for="name">Car name</label>
        <input
          type="text"
          id="name"
          class="form-control"
          placeholder="enter car name"
          v-model="carName"
        >
      </div>
      <div class="form-group">
        <label for="price">Car price</label>
        <input
          type="number"
          id="price"
          class="form-control"
          placeholder="enter car price"
          v-model="carPrice"
        >
      </div>
      <div class="form-group">
        <label for="model">Car model</label>
        <input
          type="text"
          id="model"
          class="form-control"
          placeholder="enter car model"
          v-model="carModel"
        >
      </div>
      <button type="button" class="btn btn-success" @click="addCar">Add new car</button>
    </form>
    <hr>
    <div class="col-6 offset-3">
      <table class="table table-hover">
        <tr>
          <th>#</th>
          <th>name</th>
          <th>price</th>
          <th>model</th>
          <th></th>
        </tr>
        <tr v-for="item in cars" :key="item.id">
          <td>{{item.id}}</td>
          <td>{{item.name}}</td>
          <td>{{item.price}}</td>
          <td>{{item.model}}</td>
          <td>
            <button class="btn-sm btn-warning">Edit</button>
            <button class="btn-sm btn-danger">Delete</button>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>
<script>
export default {
  name: "app",
  data() {
    return {
      msg: "Vue http",
      carName: "",
      carModel: "",
      carPrice: 0,
      url: "http://localhost:3000/cars",
      cars: []
    };
  },
  methods: {
    addCar() {
      let newObj = {
        name: this.carName,
        price: this.carPrice,
        model: this.carModel
      };
      this.$http
        .post(this.url, newObj)
        .then(data => data.json())
        // Вызов функции - для обновления списка автомобилей
        .then(val => {this.getCars()});
      this.carName = this.carModel = "";
      this.carPrice = 0;
    },
    getCars() {
      // создание запроса для получения элементов
      return this.$http
      .get(this.url)
      .then(data => data.json())
      .then(val => this.cars=val);
    }
  },
  // Инициализация списка автомобилей при создании компонента
  created() {
    this.getCars()
  }  
};
</script>

<style>
</style>

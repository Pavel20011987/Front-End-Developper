<template>
  <div id="app">    
    <h1>{{ msg }}</h1>
    <hr> 
    <form class='col-4'>
      <legend>Cars adding</legend>
      <div class="form-group">
        <label for="name">Car name</label>
        <input 
        type="text" 
        id='name' 
        class='form-control' 
        placeholder="enter car name"
        v-model='carName'>
      </div>
      <div class="form-group">
        <label for="price">Car price</label>
        <input 
        type="number" 
        id='price' 
        class='form-control' 
        placeholder="enter car price"
        v-model='carPrice'>
      </div>
      <div class="form-group">
        <label for="model">Car model</label>
        <input 
        type="text" 
        id='model' 
        class='form-control' 
        placeholder="enter car model"
        v-model='carModel'>
      </div>
      <button type='button' class="btn btn-success" @click='addCar'>Add new car</button>
    </form>
    <hr>
    <div class='col-6 offset-3'>
    <table class='table table-hover'>
      <tr>
        <th>#</th>
        <th>name</th>
        <th>price</th>
        <th>model</th>
        <th></th>
      </tr>
       
    </table>
    </div>   
  </div>
</template>
<script>
export default {
  name: 'app',
  data () {
    return {
      msg: 'Vue http',
      carName: '',
      carModel: '',
      carPrice: 0,
      url: 'http://localhost:3000'
    }
  },
  methods: {
    addCar() {
      console.log(this.carName, this.carModel, this.carPrice);
      let newObj = {
        name: this.carName,
        price: this.carPrice,
        model: this.carModel
      }
      // $http - поле у vue-resource для доступа к отправке запросов.
      // post - возвращает promice
      this.$http.post(this.url+'/cars', newObj)
      .then(data => data.json())
      .then(val => console.log(val));
      this.carName = this.carModel = '';
      this.carPrice = 0;
    }
  },
}
</script>

<style>

</style>

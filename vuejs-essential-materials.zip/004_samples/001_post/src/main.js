import Vue from 'vue'
import App from './App.vue'
import VueResource from 'vue-resource'
// подключение библиотеки vue-resource для настройки AJAX запросов
Vue.use(VueResource)
new Vue({
  el: '#app',
  render: h => h(App)
})

import Vue from 'vue'
import App from './App.vue'
import VueResource from 'vue-resource'
import VueRouter from 'vue-router';
import router from './routing';
// resource - предоставляет доступ для работы с однотипными сущностями
Vue.use(VueRouter);
Vue.use(VueResource);
// системный объект конфигурации - после регистрации библиотеки
Vue.http.options.root = 'http://localhost:3000/'
// interceptor - позволяет модифицировать определенный запрос
// регистрация нового перехватчика -для отправки токенa в запрос 
Vue.http.interceptors.push(request => {
  if (request.method === 'GET' || request.method === 'POST' || request.method === 'PUT') {
    request.headers.set('Authentication', 'Admin Token');
    request.headers.set('Accept', 'application/json');
  } else if (request.method === 'DELETE') {
    return request.respondWith('', {
      status: 401,
      statusText: 'Access denied'
      
    })
  }
})

new Vue({
  el: '#app',
  render: h => h(App),
  router
})


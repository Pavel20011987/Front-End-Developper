<template>
  <div id="app">
    <router-link tag="button" class="btn btn-primary" :to='"/add"'>Create new car</router-link>

    <div class="col-6 offset-3">
      <table class="table table-hover">
        <tr>
          <th>#</th>
          <th>name</th>
          <th>price</th>
          <th>model</th>
          <th></th>
        </tr>
        <tr v-for="item in cars" :key="item.id">
          <td>{{item.id}}</td>
          <td>{{item.name}}</td>
          <td>{{item.price}}</td>
          <td>{{item.model}}</td>
          <td>
            <button class="btn-sm btn-warning" @click='editCar(item.id)'>Edit</button>
            <button class="btn-sm btn-danger" @click="deleteCar(item.id)">Delete</button>
          </td>
        </tr>
      </table>
    </div>
  </div>
</template>
<script>
export default {
  name: "app",
  data() {
    return {
      url: "http://localhost:3000/cars",
      cars: []
    };
  },
  methods: {
    getCars() {
      // создание запроса для получения элементов
      this.$http
        .get(this.url)
        .then(data => data.json())
        .then(val => (this.cars = val));
    },
    // удаление элемента из таблицы
    deleteCar(id) {
      let ask = confirm("Вы уверены?");
      if (ask) {
        this.$http
          .delete(this.url + "/" + id)
          .then(data => data.json())
          .then(val => this.getCars());
      }
    },
    // Перенаправление на маршрут редактирования
    editCar(id) {
      this.$router.push('/edit/'+id);
    }
  },
  // Инициализация списка автомобилей при создании компонента
  created() {
    this.getCars();
  }
};
</script>

<style>
</style>
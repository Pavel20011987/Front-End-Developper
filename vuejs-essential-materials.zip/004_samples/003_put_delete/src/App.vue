<template>
  <div id="app" class='container'>
    <h1>{{ msg }}</h1>
    <hr>
    <router-view></router-view>    
    <hr>
  </div>
</template>
<script>
import Table from './Table.vue';
export default {
  name: "app",
  data() {
    return {
      msg: "Vue http",    
      
    };
  },
  methods: {
  },
  components: {
    'app-table': Table
  }
};
</script>

<style>
</style>
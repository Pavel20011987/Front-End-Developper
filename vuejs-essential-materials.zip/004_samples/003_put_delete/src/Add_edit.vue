<template>
  <div id="app">
    <form class="col-4">
      <legend v-if="adding">Cars adding</legend>
      <legend v-else>Car edit</legend>
      <div class="form-group">
        <label for="name">Car name</label>
        <input
          type="text"
          id="name"
          class="form-control"
          placeholder="enter car name"
          v-model="carName"
        >
      </div>
      <div class="form-group">
        <label for="price">Car price</label>
        <input
          type="number"
          id="price"
          class="form-control"
          placeholder="enter car price"
          v-model="carPrice"
        >
      </div>
      <div class="form-group">
        <label for="model">Car model</label>
        <input
          type="text"
          id="model"
          class="form-control"
          placeholder="enter car model"
          v-model="carModel"
        >
      </div>
      <button v-if="adding" type="button" class="btn btn-success" @click="addCar">Add new car</button>
      <button v-if="!adding" type="button" class="btn btn-primary" @click="editCar(carId)">Edit car</button>
      <button type="button" class="btn btn-secondary" @click="goBack">Return</button>
    </form>
  </div>
</template>
<script>
export default {
  name: "app",
  data() {
    return {
      carId: 0,
      carName: "",
      carModel: "",
      carPrice: 0,
      url: "http://localhost:3000/cars",
      adding: true
    };
  },
  methods: {
    addCar() {
      let newObj = {
        name: this.carName,
        price: this.carPrice,
        model: this.carModel
      };
      this.$http
        .post(this.url, newObj)
        .then(data => data.json())
        .then(val => {
          console.log(val);
          this.goBack();
        });
    },
    getCar(id) {
      this.$http
        .get(this.url + "/" + id)
        .then(data => data.json())
        .then(val => {
          this.carName = val.name;
          this.carPrice = val.price;
          this.carModel = val.model;
          this.carId = val.id;
        });
    },
    goBack() {
      this.$router.push("/home");
    },
    editCar(id) {
      let carObj = {
        name: this.carName,
        price: this.carPrice,
        model: this.carModel
      };
      this.$http
        .put(this.url + "/" + id, carObj)
        .then(val => val.json())
        .then(data => this.goBack());
    }
  },
  created() {
    let params = this.$route.params;
    if (params.id) {
      this.adding = false;
      this.getCar(params.id);
    }
  }
};
</script>

<style>
</style>
(function() {
  var Customer, c1, c2;

  Customer = (function() {
    function Customer() {}

    return Customer;

  })();

  c1 = new Customer();

  c2 = new Customer;

}).call(this);

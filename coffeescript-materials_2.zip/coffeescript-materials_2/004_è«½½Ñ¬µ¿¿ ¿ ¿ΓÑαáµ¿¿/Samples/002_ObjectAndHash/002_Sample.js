(function() {
  var height, obj, width;

  width = 10;

  height = 15;

  obj = {
    width: width,
    height: height
  };

  console.log(obj);

}).call(this);

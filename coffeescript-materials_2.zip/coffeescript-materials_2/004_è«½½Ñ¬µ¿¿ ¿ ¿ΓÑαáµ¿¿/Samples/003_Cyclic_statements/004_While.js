(function() {
  var count;

  count = 0;

  while (count < 10) {
    document.write("Iteration № " + count + " <br />");
    count++;
  }

}).call(this);

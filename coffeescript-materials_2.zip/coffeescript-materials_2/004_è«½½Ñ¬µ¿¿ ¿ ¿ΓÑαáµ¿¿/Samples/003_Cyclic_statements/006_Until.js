(function() {
  var count;

  count = 0;

  while (!(count > 9)) {
    document.write("Count = " + count + " <br/>");
    count++;
  }

}).call(this);

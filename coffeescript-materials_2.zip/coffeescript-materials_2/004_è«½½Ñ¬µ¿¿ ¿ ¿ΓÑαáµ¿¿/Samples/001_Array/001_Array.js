(function() {
  var a;

  a = ['a', 'b', 'c'];

  console.log(a);

}).call(this);

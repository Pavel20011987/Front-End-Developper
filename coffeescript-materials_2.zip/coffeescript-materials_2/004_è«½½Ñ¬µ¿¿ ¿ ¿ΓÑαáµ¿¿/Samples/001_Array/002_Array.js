(function() {
  var arr;

  arr = ['Item 1', 'Item 2', 'Item 3'];

  docoment.write(arr);

}).call(this);

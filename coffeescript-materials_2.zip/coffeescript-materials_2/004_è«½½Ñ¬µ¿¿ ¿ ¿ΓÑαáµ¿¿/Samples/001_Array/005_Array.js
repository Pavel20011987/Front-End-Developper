(function() {
  var var1, var2, _ref;

  var1 = "1";

  var2 = "2";

  document.write("var1 = " + var1 + " </br>");

  document.write("var2 = " + var2 + " </br>");

  _ref = [var2, var1], var1 = _ref[0], var2 = _ref[1];

  document.write("var1 = " + var1 + " </br>");

  document.write("var2 = " + var2 + " </br>");

}).call(this);

(function() {
  var login;

  login = "Andrew";

  if (login === "Andrew") {
    document.write("Hello, Andrew!");
  }

}).call(this);

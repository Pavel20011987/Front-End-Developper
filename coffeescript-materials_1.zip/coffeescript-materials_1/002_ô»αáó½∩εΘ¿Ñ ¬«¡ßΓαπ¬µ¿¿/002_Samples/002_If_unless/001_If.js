(function() {
  var a, today;

  a = true;

  if (a) {
    console.log("a is true");
  }

  today = "Friday";

  if (today === "Friday") {
    console.log("Today is Friday");
  }

}).call(this);

(function() {
  var today;

  today = "Monday";

  if (today === "Monday") {
    document.write("Today is Monday");
  } else {
    document.write("Today is NOT Monday");
  }

  document.write("<br/>");

  if (typeof x !== "undefined" && x !== null) {
    document.write("" + x);
  } else {
    document.write("x is not defined");
  }

}).call(this);

(function() {
  var string, znak;

  string = "Hello ";

  string += "world";

  znak = "!";

  document.write(string + znak);

}).call(this);

(function() {
  var a, b;

  a = 1;

  b = 2;

  if (a > b) {
    console.log("a > b");
  }

  console.log("a < b");

}).call(this);

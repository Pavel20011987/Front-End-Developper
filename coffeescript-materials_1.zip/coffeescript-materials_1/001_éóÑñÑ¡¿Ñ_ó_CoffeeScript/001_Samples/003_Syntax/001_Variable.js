(function() {
  var a, b, c, color;

  a = 'Это строка';

  alert(a);

  b = 5;

  c = 10;

  alert(b + ' ' + c);

  color = ['red', 'green', 'blue'];

  alert(color);

}).call(this);

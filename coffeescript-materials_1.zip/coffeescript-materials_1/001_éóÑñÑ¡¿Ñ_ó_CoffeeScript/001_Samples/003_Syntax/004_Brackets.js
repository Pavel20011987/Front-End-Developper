(function() {
  var f;

  alert("First example");

  f = function() {
    console.log("Body of function");
  };

  f();

}).call(this);

(function() {
  var Name, field, text;

  Name = "Ivan";

  field = 'My name is #{Name}';

  document.write(field);

  document.write("<br />");

  text = 'first line \\ Second line';

  document.write(text);

}).call(this);

(function() {
  alert("Hello world!");

}).call(this);
